package edu.ecu.ec.ProyectoEmprendimiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoEmprendimientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
