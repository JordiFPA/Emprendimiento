package edu.ecu.ec.ProyectoEmprendimiento.Coneccion;

import edu.ecu.ec.ProyectoEmprendimiento.Models.ProductSale;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoSaleRepository extends JpaRepository<ProductSale,Long> {

}
